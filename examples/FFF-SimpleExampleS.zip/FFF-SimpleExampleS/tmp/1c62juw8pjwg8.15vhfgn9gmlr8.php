<!DOCTYPE html>
<html>
   <head>
      <title><?= $html_title ?></title>
      <meta charset="utf-8" />
   </head>
   <body>

<!-- 
Check if the session username is UNSET; if not, give user's name and logout button, then show page content.
If it is UNSET, check if this is login page, in which case show content; 
but if not login page, say "Not logged in" and give login link.
 -->
   	  <?php if ($SESSION['userName']=='UNSET'): ?>
		  
		  	  <?php if ($thisIsLoginPage): ?>
				  
					  <?php echo $this->render($content,NULL,get_defined_vars(),0); ?>
				  
				  <?php else: ?>
					  <span class="loggedin"> Not logged in.</span>
					  <br /><a href="<?= $BASE ?>/login/in">Log in</a>
				  
			  <?php endif; ?>
		  
		  <?php else: ?>
			  <span class="loggedin"> Logged in as <?= $SESSION['userName'] ?>.
			  <form method=post action="<?= $BASE ?>/logout">
				<input type="submit" name="submit" value="Logout">
			  </form>
			  </span>
			  <hr />
			  <?php echo $this->render($content,NULL,get_defined_vars(),0); ?>
		  
	  <?php endif; ?>
      
   </body>
</html>
