<?php include '../../functions.php'; ?>
<?php 
header('Location: index.php');

// NB the functions.php contains reuseable code, in this case a db connection
// the header function above redirects to the index.php on completion...
// ... you mustn't put any HTML before this or it won't work!

if($_POST['post_submit_check']) // check to see if form was submitted, via a hidden field
	{//  yes - so run the query

$mysqli = getConnection();

/* assign parameter values from Form fields */
// we store them here so we can (possibly) reuse them later
$post_title = $_POST['post_title'];
$post_text = $_POST['post_text'];
$post_author = $_POST['post_author'];
//
$duedate = $_POST['datepicker'];

$last_insert_id = 0;// we'll use this to store the last insert id

/* create a prepared statement */
$stmt =  $mysqli->stmt_init();

if ($stmt->prepare("INSERT INTO jr_blogpost (post_title, post_text, post_author, post_date, embargo_date)
	VALUES (?,?,?,NOW(),?)")) {
	// NOW() is a special SQL function

    /* bind parameters for ? markers, in this case string, string, string */
    $stmt->bind_param("ssss", $post_title, $post_text, $post_author, $duedate);

    /* execute query */
    $stmt->execute();
	
	$last_insert_id = $mysqli->insert_id;
	
    /* close statement */
    $stmt->close();
}

// now deal with the categories
// multiple inserts all using a common last insert id from the previous insert above

// count the number of selected objects
$cb = count($_POST['checkboxes']);// same as myArray.length()

/* create a prepared statement */
$stmt =  $mysqli->stmt_init();



if ($stmt->prepare("INSERT INTO jr_blogcategoryrels (blog_id,cat_id) VALUES (?,?)")) {
	
	// we loop around our array of id's to populate the ?
	for($i = 0; $i < $cb; $i++){
	
	/* bind parameters for ? markers, in this integer id */
    $stmt->bind_param("ii", $last_insert_id,$_POST['checkboxes'][$i]);

    /* execute query */
    $stmt->execute();
	
	}
	
    /* close statement */
    $stmt->close();
}



/* close connection */
$mysqli->close();

echo "<p><a href=\"index.php\">index<a/></p>";

}

else {
	echo "<p>Not a proper form submission</p>";
}
	

?>