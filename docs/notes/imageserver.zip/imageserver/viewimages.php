<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>ImageServer Images</title>
</head>

<body>
<h3>Thumbnails (click for full size image):</h3>

<?php
// This page will display thumnails of all the images in the DB, along with a link to delete them.
// Each thumbnail is also a link to the original-size image.

// We'll need manpics stuff here ...
require("manpics.php");

// If the URL has "delete" as a parameter, then delete the image as given by ID.
// Do this first, so that we see the images withiout the deleted one.
if (isset($_GET["picID"]) && isset($_GET["delete"])) {
	Manpics::deletePicService($_GET["picID"]);
}

// $picStuff here is a MySQLi resultset object as returned by Manpics::picInfoService().  So we can use normal
// resultset methods like fetch_assoc() to retrieve material from it.
// Note that the img tag src used in the HTML we write is always imagelocator.php, with the appropriate filename:
// this is how we get the images we want (thumbnail or otherwise) from above the web root.
$picStuff = Manpics::picInfoService();
if ($picStuff->num_rows == 0)
	echo "<p>-- No images in database</p>\n";
else {
	while ($row = $picStuff->fetch_assoc()) {
		printf("<a href=\"?delete=yes&picID=%d\">Delete</a>\n", $row["id"]);
		printf("<a href=\"imagelocator.php?filename=%s\" target=\"_blank\"><img src=\"imagelocator.php?thumb=yes&filename=%s\" /></a> %s<br/>\n", $row["picfile"], $row["picfile"], $row["picname"]);
	}
}

?>
</body>
</html>