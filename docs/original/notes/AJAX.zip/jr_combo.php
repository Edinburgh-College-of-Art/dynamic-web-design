<?php
include("../../../php_functions/functions.php");

// this code adapted from http://www.w3schools.com/php/php_ajax_database.asp

// here we retrieve the value passed into the url
$q = "";
if(isset($_POST["LastName"])) $q = "%" . $_POST["LastName"] . "%";

// here we set the initial value of any hints we may have
$hint = "";

// get a DB connection
$mysqli = getConnection();

/* create a prepared statement */
$stmt =  $mysqli->stmt_init();

/* create a prepared statement */
$stmt =  $mysqli->stmt_init();

if ($stmt->prepare("SELECT * FROM jr_quahog WHERE LastName LIKE ?")) {

	/* bind params */
    $stmt->bind_param("s",$q);

    /* execute query */
    $stmt->execute();
	
	/* bind your result columns to variables */
    $stmt->bind_result($id, $FirstName, $LastName, $Age, $Hometown, $Job);
	
	/* store result */
    $stmt->store_result();	
	
	if($stmt->num_rows){// are there any results?
	
	echo "<table border='1'>
			<tr>
			<th>Firstname</th>
			<th>Lastname</th>
			<th>Age</th>
			<th>Hometown</th>
			<th>Job</th>
			</tr>";
	
    while($stmt->fetch()) {
          echo "<tr>";
		  echo "<td>" . $FirstName. "</td>";
		  echo "<td>" . $LastName . "</td>";
		  echo "<td>" . $Age . "</td>";
		  echo "<td>" . $Hometown . "</td>";
		  echo "<td>" . $Job . "</td>";
		  echo "</tr>";
    	}
		
	echo "</table>";
		
	}
	
	
    /* close statement */
    $stmt->close();
}

/* close connection */
$mysqli->close();

?>
