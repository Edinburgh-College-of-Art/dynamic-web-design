<p><?= $message ?></p>
<form id="form1" name="form1" method="post" action="<?= $BASE ?>/login">
  <input name="uname" type="text" placeholder="Please enter your user name" id="name" size="50" />
  <br />
  <input name="password" type="password" placeholder="Please enter your password" id="pass" size="50" />
<p>
  <input type="submit" name="Submit" value="Login" />
</p>
</form>
