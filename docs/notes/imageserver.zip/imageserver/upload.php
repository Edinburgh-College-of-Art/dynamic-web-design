<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>Upload image form</title>
</head>

<body>
<!--
This is just a form, nothing unusual about it except that it uses the input type "file",
which causes a button launching the file browser to appear.
-->
<form action="upload.php" method="post" enctype="multipart/form-data">
<label for="file">Select a file:</label>
<input type="file" name="file" id="file" /> 
<br />
<label for="picname">Picture title:</label>
<input type="text" name="picname" id="picname" /> 
<br />
<input type="submit" name="submit" value="Submit" />
</form>

<?php
// We have to include this: "require" will cause a fatal error if it isn't there
require("manpics.php");

if (isset($_POST["submit"])) {
  echo "<h3>Thanks for your upload ...</h3>\n";

  // This is calling the function uploadPic that belongs to the class Manpics, as defined in manpics.php
  Manpics::uploadPic($_FILES["file"],$_POST["picname"]);
}
?>
</body>
</html>