<?php include '../../functions.php'; ?>
<!-- the bit above grabs code from the page it includes -->
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>JR - PHP - DETAIL PAGE</title>
</head>

<body>

<p><a href="index.php">Index</a></p>

<?php

/* grab the url paramter */
// we want the url parameter so that we can...
// 1. use it to retrieve the data from the DB
// 2. use it to insert into the comments table to 'key' the blog post and comments

// first set a default value, just in case it can't be found in the URL
$post_id_url = 0;
// now try to get it in the URL
$post_id_url = $_GET['p_id'];

// IS THIS AN INSERT OF A COMMENT?

if(isset($_POST['comment_submit_check'])) // check to see if form was submitted via a hidden field
	{//  yes - so run the query

/* getConnection() function is in the functions.php that is 'included' at the top */
$mysqli = getConnection();

/* assign parameter values */
$post_text = $_POST['post_text'];
$post_author = $_POST['post_author'];

/* create a prepared statement */
$stmt =  $mysqli->stmt_init();

if ($stmt->prepare("INSERT INTO jr_blogcomment (post_id, comment_text, comment_author, comment_date)
	VALUES (?,?,?,NOW())")) {

    /* bind parameters for ? markers, NB $post_id_url comes from our url parameter */
    $stmt->bind_param("iss", $post_id_url, $post_text, $post_author);

    /* execute query */
    $stmt->execute();
	
    /* close statement */
    $stmt->close();
}

/* close connection */
$mysqli->close();

}

?>

<?php

// GETTING THE CONTENT

/* getConnection() function is in the functions.php that is 'included' at the top */
$mysqli = getConnection();


/* create a prepared statement */
$stmt =  $mysqli->stmt_init();

if ($stmt->prepare("SELECT id, post_title, post_text, post_author FROM jr_blogpost WHERE id = ?")) {
	
	/* bind parameters for markers */
    $stmt->bind_param("i", $post_id_url);

    /* execute query */
    $stmt->execute();
	
	/* bind your result columns to variables */
    $stmt->bind_result($id, $post_title, $post_text, $post_author);
	
	/* store result */
    $stmt->store_result();
	
	if($stmt->num_rows){// are there any results?
	
	/* show the number of results */
	//echo "<p>".$stmt->num_rows."<p>";
	
	/* fetch the result of the query & loop round the results */
    while($stmt->fetch()) {
        echo "<h2>".$post_title."</h2>";// dot delimited query values \" escaped character
		echo "<div>".$post_text."</div>";
		echo "<div>Author: ".$post_author."</div>";
    	}
	
	}
	
	else {// there aren't any results
		echo "<p>There isn't any content</p>";
	}

	
    /* close statement */
    $stmt->close();
}

/* close connection */
$mysqli->close();

?>

<hr />

<?php

// GETTING THE COMMENTS


$mysqli = getConnection();


/* create a prepared statement */
$stmt =  $mysqli->stmt_init();

if ($stmt->prepare("SELECT comment_text, comment_author FROM jr_blogcomment WHERE post_id = ?  ORDER BY comment_date DESC")) {
	
	/* bind parameters for markers */
    $stmt->bind_param("i", $post_id_url);

    /* execute query */
    $stmt->execute();
	
	/* bind your result columns to variables */
    $stmt->bind_result($comment_text, $comment_author);
	
	/* store result */
    $stmt->store_result();
	
	if($stmt->num_rows){// are there any results?
	
	/* show the number of results */
	//echo "<p>".$stmt->num_rows."<p>";
	echo "<h3>Comments</h3>";
	
	/* fetch the result of the query & loop round the results */
    while($stmt->fetch()) {
		echo "<div>".$comment_text."</div>";
		echo "<div>Author: ".$comment_author."</div>";
    	}
	
	}
	
	else {// there aren't any results
		echo "<p>There aren't any comments</p>";
	}

	
    /* close statement */
    $stmt->close();
}

/* close connection */
$mysqli->close();

?>

<hr />

<h2>Add a comment</h2>

<!-- NB there is a small snippet of PHP in the form that passes the url parameter back into the page, we need this for the db insertion and also to retrieve page content -->
<form action="detail.php?p_id=<?php echo $post_id_url; ?>" method="post">
<div>
<p>Comment</p>
<textarea name="post_text"></textarea>
</div>
<div>
<p>Author</p>
<input type="text" name="post_author"/>
</div>
<div>
<p>&nbsp;</p>
<input type="hidden" name="comment_submit_check" value="1"/> 
<input type="submit" name="submit"/>
</div>

</form>


</body>
</html>