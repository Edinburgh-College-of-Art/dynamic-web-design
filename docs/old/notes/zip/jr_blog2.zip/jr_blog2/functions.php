<?php
session_start(); // start up your PHP session!

// this document should be placed ABOVE/OUTSIDE your html folder on the playground

function getConnection(){// change the details below for your db connection
	$conn = new mysqli("localhost", "dwd11_jrawlins", "<password>", "dwd11_jrawlins");
	
	/* check connection */
	if (mysqli_connect_errno()) {
		printf("Connect failed: %s\n", mysqli_connect_error());
		exit();
	}
	
	return $conn;
	
}


// in this example we can pass in a custom css class,
// category (which could be used in the select) and linkurl
// (which points to a specific template)
// this means you get a 'dynamic' instance of this function.
function getBlogIndex($class,$category,$linkurl){
if($linkurl == "") $linkurl = "default.php";// you could always point to a default
/* getConnection() */
$mysqli = getConnection();
/* create a prepared statement */
$stmt =  $mysqli->stmt_init();
if ($stmt->prepare("SELECT id, post_title FROM jr_blogpost ORDER BY post_date DESC")) {
    /* execute query */
    $stmt->execute();	
	/* bind your result columns to variables, e.g. id column = $post_id */
    $stmt->bind_result($post_id, $post_title);	
	/* store result */
    $stmt->store_result();	
	if($stmt->num_rows){// are there any results?	
	/* show the number of results */
	//echo "<p>There are ".$stmt->num_rows." posts<p>";	
	echo "<ul>\n";// open a list, \n = new line
	/* fetch the result of the query & loop round the results */
    while($stmt->fetch()) {
		// for each row in the resultset print out a link in a list item
		// NB the link includes a url parameter (p_id here, but whatever you want)
		// that is passed to the detail page, and picked up via $_GET
        echo "<li class='".$class."'><a href=\"".$linkurl."?p_id=".$post_id."\">".$post_title."</a></li>\n";
		// dot delimited query values \" escaped character
    	}	
	echo "</ul>\n"; // close the list,  \n = new line
	}
	else {// there aren't any results
		echo "<p>There isn't any content</p>";
	}
    /* close statement */
    $stmt->close();
}
/* close connection */
$mysqli->close();	
}

?>