<?php include '../../functions.php'; ?>
<!-- the bit above grabs code from the page it includes -->
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>JR - PHP - INDEX</title>
 <link href="//ajax.googleapis.com/ajax/libs/jqueryui/1.8/themes/base/jquery-ui.css" rel="stylesheet" type="text/css"/>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.5/jquery.min.js"></script>
  <script src="//ajax.googleapis.com/ajax/libs/jqueryui/1.8/jquery-ui.min.js"></script>
  
<script>
	$(function() {
		$( "#datepicker" ).datepicker({dateFormat: 'yy-mm-dd'});
	});
</script>
</head>

<body>


<form action="insert.php" method="post">
<div>
<p>Title</p>
<input type="text" name="post_title"/>
</div>
<div>
<p>Text</p>
<textarea name="post_text"></textarea>
</div>
<div>
<p>Author</p>
<input type="text" name="post_author"/>
</div>

<p>Embargo Date</p>
<input id="datepicker" type="text" name="datepicker" value=""/>

<div>
<p>Categories</p>

<?php // getting categories

/* getConnection() function is in the functions.php that is 'included' at the top */
$mysqli = getConnection();


/* create a prepared statement */
$stmt =  $mysqli->stmt_init();

if ($stmt->prepare("SELECT id, cat_title FROM jr_blogcategories ORDER BY id DESC")) {

    /* execute query */
    $stmt->execute();
	
	/* bind your result columns to variables, e.g. id column = $post_id */
    $stmt->bind_result($cat_id, $cat_title);
	
	/* store result */
    $stmt->store_result();
	
	if($stmt->num_rows){// are there any results?
	
	/* show the number of results */
	//echo "<p>There are ".$stmt->num_rows." posts<p>";
	
	echo "<ul>\n";// open a list, \n = new line
	
	
	/* fetch the result of the query & loop round the results */
    while($stmt->fetch()) {
		// for each row in the resultset print out a link in a list item
		// NB the link includes a url parameter (p_id here, but whatever you want)
		// that is passed to the detail page, and picked up via $_GET
        echo "<li><input type='checkbox' name='checkboxes[]' value='".$cat_id."'/> ".$cat_title."</li>\n";
		// dot delimited query values \" escaped character
    	}
		
		
	echo "</ul>\n"; // close the list,  \n = new line
	}
	
	
	else {// there aren't any results
		echo "<p>There isn't any content to delete</p>";
	}

	
    /* close statement */
    $stmt->close();
}

/* close connection */
$mysqli->close();


?>

<p>&nbsp;</p>
<!-- the hidden field is used to check that the form was submitted, and also which form -->
<input type="hidden" name="post_submit_check" value="1"/> 
<input type="submit" name="submit" value="submit"/>
</div>

</form>

<hr/>

<?php

/* getConnection() function is in the functions.php that is 'included' at the top */
$mysqli = getConnection();


/* create a prepared statement */
$stmt =  $mysqli->stmt_init();

if ($stmt->prepare("SELECT id, post_title FROM jr_blogpost ORDER BY post_date DESC")) {

    /* execute query */
    $stmt->execute();
	
	/* bind your result columns to variables, e.g. id column = $post_id */
    $stmt->bind_result($post_id, $post_title);
	
	/* store result */
    $stmt->store_result();
	
	if($stmt->num_rows){// are there any results?
	
	/* show the number of results */
	//echo "<p>There are ".$stmt->num_rows." posts<p>";
	
	echo "<ul>\n";// open a list, \n = new line
	
	
	/* fetch the result of the query & loop round the results */
    while($stmt->fetch()) {
		// for each row in the resultset print out a link in a list item
		// NB the link includes a url parameter (p_id here, but whatever you want)
		// that is passed to the detail page, and picked up via $_GET
        echo "<li><a href=\"detail.php?p_id=".$post_id."\">".$post_title."</a></li>\n";
		// dot delimited query values \" escaped character
    	}
		
		
	echo "</ul>\n"; // close the list,  \n = new line
	}
	
	
	else {// there aren't any results
		echo "<p>There isn't any content</p>";
	}

	
    /* close statement */
    $stmt->close();
}

/* close connection */
$mysqli->close();

?>

</body>
</html>