<?php
// Notice there is no HTML on this page: no headers, nothing.  This is ABSOLUTELY CRUCIAL to the page working properly,
// because the headers are written by the code below and must not exist before that.

// We need to include the manpics material here
require("manpics.php");

// imagelocator.php  -- adapted from code at http://www.kobashicomputing.com/serving-images-outside-document-root-via-php
// Given a filename on the URL, it will fetch and display the corresponding file from above the web root (location defined
// by Manpics::$imagestore in manpics).  If given "thumb" on the URL, it retrieves the corresponding thumbnail.

// This defines a class, although we aren't going to create any objects from it.  It helps to keep the code organised, all the same.
class ImageLocator {
	// Defining an array that tells us which mime file types are allowed to be uploaded. It's good to limit these, for safety.
  static $allowedMimeTypes = array("jpg" => "image/jpeg",
                                   "png" => "image/png",
                                   "gif" => "image/gif");
	
  // This function checks that the filename has been provided and has a suitable extension, etc. 
  // Then it creates the complete path, attaching the filename to the basepath it has been given,
  // checks that there is a file in that location, and returns the path.
  static function ValidateImagePath($basepath, $filename) {
    // Make sure filename is set
    if (!isset($filename)) {
      self::SendErrorHeader(404);
	  echo "<h2>Error: no image file given.</h2>\n";
	  exit;
	}
    // Make sure filename has minimum length (.ext)
    if (strlen($filename) <= 4) {
      self::SendErrorHeader(404);
	  echo "<h2>Error: filename too short.</h2>\n";
	  exit;
	}
    // Make sure its a legal image extension
    $pathParts = pathinfo($filename);
    if (!array_key_exists($pathParts["extension"], self::$allowedMimeTypes)) {
      self::SendErrorHeader(404);
	  echo "<h2>Error: disallowed file type.</h2>\n";
	  exit;
	}
    // Fix up directory separators
    $bLastChar = substr($basepath, -1, 1) == "/" ? true : false;
    $bFirstChar = substr($filename, 0, 1) == "/" ? true : false;
    if ($bLastChar && $bFirstChar)
      $imagepath = substr($basepath, 0, strlen($basepath)-1) . $filename;
    elseif (!$bLastChar && !$bFirstChar)
      $imagepath = $basepath . "/" . $filename;
    else
      $imagepath = $basepath . $filename;
    // Make sure the image file exists
    if (!file_exists($imagepath)) {
      self::SendErrorHeader(404);
	  echo "<h2>Error: no such image path: ".$imagepath."</h2>\n";
	  exit;
	}
    return($imagepath);
  }
  
  // This function just sends error headers appropriate to particular types of error.  Most of them are not used here.
  static function SendErrorHeader($error) {
    switch($error) {
      case 400:
        header("HTTP/1.0 400 Bad Request");
        break;
      case 401:
        header("HTTP/1.0 401 Unauthorized");
        break;
      case 403:
        header("HTTP/1.0 403 Forbidden");
        break;
      case 404:
      default:
        header("HTTP/1.0 404 Not Found");
        break;
    }
	echo "<h2>Error: Failed to validate image path.</h2>\n";
  }
  
  // Function to send a mime header appropriate to the type of image file: the builtin PHP function header() does this.
  static function SendImageHeader($imagepath) {
    $pathParts = pathinfo($imagepath);
    $extension = $pathParts["extension"];
    $mimeType = self::$allowedMimeTypes[$extension];
	header("Content-type: " . $mimeType);
  }
  
  // The PHP builtin readfile() just gets the content of the file and outputs it, so this will be pure image data, but the
  // header will ensure that it is seen as the right type of file when the browser includes it as an image.
  static function SendImage($imagefile) {
	$imagepath = self::ValidateImagePath(Manpics::$imagestore, $imagefile);
	self::SendImageHeader($imagefile);
	readfile($imagepath);
  }
}

// This gets executed via the img src (typically -- or any URL)
// IF "thumb" is a query parameter, then show the thumbnail file instead.
if (isset($_GET["thumb"])) {
	ImageLocator::SendImage(Manpics::thumbFile($_GET["filename"]));
}
else
	ImageLocator::SendImage($_GET["filename"]);
?>