<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>AJAX 1</title>

<script type="text/javascript">

/*
This code adapted from http://www.w3schools.com/php/php_ajax_database.asp

Explanation: When the query is sent from the JavaScript to the PHP file, the following happens:

    PHP opens a connection to a MySQL server
    The correct person is found
    An HTML table is created, filled with data, and sent back to the "txtHint" placeholder

*/


// the function is called when the user changes the value of the form select below
function showUser(str)
{
// if the string == empty then the first option was selected
// so we set the HTML inside our Div to be empty, then quit the script
if (str=="")
  {
  document.getElementById("responseTable").innerHTML="";
  return;
  }
  
// this section creates the right kind of XML http request based on browser  
if (window.XMLHttpRequest)
  {// code for IE7+, Firefox, Chrome, Opera, Safari
  xmlhttp=new XMLHttpRequest();
  }
else
  {// code for IE6, IE5
  xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  
// this section is the listener for the returned data from the DB
// if we have returned some data, this script is alerted to a 'state change'
xmlhttp.onreadystatechange=function()
  {
  if (xmlhttp.readyState==4 && xmlhttp.status==200)
    {
	// this section writes the responseText from our getuserphp into the Div	
    document.getElementById("responseTable").innerHTML=xmlhttp.responseText;
    }
  }

// this section opens an http request so our url param 
// can be sent from the form into the php that manages the db conn  
xmlhttp.open("GET","jr_getuser.php?q="+str,true);

// this code actually sends the GET message above
xmlhttp.send();

}


/*
This code adapted from http://www.w3schools.com/php/php_ajax_php.asp

Explanation: If there is any text sent from the JavaScript the following happens:

    Find a name matching the characters sent from the JavaScript
    If no match were found, set the response string to "no suggestion"
    If one or more matching names were found, set the response string to all these names
    The response is sent to the "txtHint" placeholder


*/

// see the annotations above for an explanation of this code, since it's mostly the same
function showHint(str)
{
if (str.length==0)
  {
  document.getElementById("txtHint").innerHTML="";
  return;
  }
// check browser to create right request
if (window.XMLHttpRequest)
  {// code for IE7+, Firefox, Chrome, Opera, Safari
  xmlhttp=new XMLHttpRequest();
  }
else
  {// code for IE6, IE5
  xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
// deal with this last
xmlhttp.onreadystatechange=function()
  {
  if (xmlhttp.readyState==4 && xmlhttp.status==200)
    {
    document.getElementById("txtHint").innerHTML=xmlhttp.responseText;
    }
  }
// create a page view request  
xmlhttp.open("GET","jr_gethint.php?q="+str,true);
// now send the request
xmlhttp.send();
}


function showResult(str)
{
if (str.length==0)
  {
  document.getElementById("livesearch").innerHTML="";
  document.getElementById("livesearch").style.border="0px";
  return;
  }
if (window.XMLHttpRequest)
  {// code for IE7+, Firefox, Chrome, Opera, Safari
  xmlhttp=new XMLHttpRequest();
  }
else
  {// code for IE6, IE5
  xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
xmlhttp.onreadystatechange=function()
  {
  if (xmlhttp.readyState==4 && xmlhttp.status==200)
    {
    document.getElementById("livesearch").innerHTML=xmlhttp.responseText;
    document.getElementById("livesearch").style.border="1px solid #A5ACB2";
    }
  }
xmlhttp.open("GET","jr_livesearch.php?q="+str,true);
xmlhttp.send();
}

</script>
</head>
<body>
<h2>Example 1</h2>
<!-- lookup in db based on select > option -->
<form>
<select name="users" onchange="showUser(this.value)">
<option value="">Select a person:</option>
<option value="1">Peter Griffin</option>
<option value="2">Lois Griffin</option>
<option value="3">Glenn Quagmire</option>
<option value="4">Joseph Swanson</option>
</select>
</form>
<br />
<div id="responseTable">Person info will be listed here.</div>

<h2>Example 2</h2>
<!-- lookup in db based on input -->
<p>Start typing a name in the input field below:</p>
<form action="jr_combo.php" method="post">
Last name: <input type="text" name="LastName" onkeyup="showHint(this.value)" size="20" />
<input type="submit" name="submit" value="submit"/>
</form>
<p>Suggestions: <span id="txtHint"></span></p>


<h2>Example 3</h2>
<form>
<input type="text" size="30" onkeyup="showResult(this.value)" />
<div id="livesearch"></div>
</form>
 
</body>
</html>
