<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<!-- this tells the browser to declare its width -->
<meta name="viewport" content="width=device-width;" />
<title>DD Blog - <?php getBpTitle(); ?></title>
<!-- this is the link to our basic stylesheet -->
<link href="css/jr_dd_basic.css" rel="stylesheet" type="text/css" />
<!-- this is the link to the google font -->
<!-- read more at http://www.google.com/webfonts -->
<link href='http://fonts.googleapis.com/css?family=Anaheim' rel='stylesheet' type='text/css'>
<!-- this is where we import the styles for a 'screen' -->
<style type="text/css" media="screen">
@import url("css/jr_dd_screen.css");
</style>
<!-- this is where we link to the mediaqueries css to serve styles for different platforms -->
<!-- Phone Portrait -->
<link href="css/jr_dd_mobile_320.css" rel="stylesheet" type="text/css" media="only screen and (max-width:320px)" />
</head>