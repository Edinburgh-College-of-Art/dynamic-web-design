<script type="text/javascript" language="javascript">
function showContent(divToShow,divText){
	// now do the hiding showing
	if(document.getElementById(divToShow).className == 'hideContent'){
		document.getElementById(divToShow).className = 'showContent';
		document.getElementById(divText).innerHTML = "Show me less...";
	}
	else {
		document.getElementById(divToShow).className = 'hideContent';
		document.getElementById(divText).innerHTML = "Show me more...";
		}
}
</script>
</html>
