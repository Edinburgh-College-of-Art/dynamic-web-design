<ul>
	<li><a href="index.php" id="a_home">Home</a></li>
	<li><a href="jr_dd_assets.php" id="a_assets">Assets</a></li>
	<li><a href="jr_dd_blogindex.php"  id="a_blog">Blog</a></li>
</ul>