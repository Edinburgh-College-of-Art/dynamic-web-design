<?php
include("../../../php_functions/functions.php");

// this code adapted from Jules' AJAX example by replacing the xmlhttp-based 
// coee with jQuery-based code
// ... now modified also to include the PHP elements ...
// In this version, the idea is that instead of using different scripts, we use
// different functions in this script, triggered by a choice signalled on the URL


// get a DB connection -- we will always want this (except when going straight to HTML)
$mysqli = getConnection();

/* create a prepared statement */
$stmt =  $mysqli->stmt_init();


// here we retrieve the "q" value passed into the url
$q = "";
if (isset($_GET["q"])) $q = $_GET["q"];

// here we retrieve the "func" value passed into the url, specifying a function to use
// (unless the Example 2 form was submitted, in which case func is unset)
$func = "";
if (isset($_GET["func"])) $func = $_GET["func"];


if (isset($_POST["LastName"])) {	// In this case, the form for Example 2 was submitted ...
	$func = "combo";
	$q = $_POST["LastName"];
}


// swtch statement to select appropriate function to call as specified on URL
// $q and $stmt passed in here just to avoid making them explicitly global
switch ($func) {
	case "gethint": 
		getHint($q, $stmt);
		exit();
	case "getuser":
		getUser($q, $stmt);
		exit();
	case "livesearch":
		liveSearch($q, $stmt);
		exit();
	case "combo":
		combo($q, $stmt);
		exit();
	default:		// do nothing -- just continue to HTML
}


/* close statement */
//$stmt->close();		// commented out because causes an error I don't understand ...

/* close connection */
$mysqli->close();

// That's the end of the program.
// Now the functions, which will be called from above as appropriate
// The code in most of these is just copy-&-pasted from Jules' original scripts

function getHint($q, $stmt) {
	// here we set the initial value of any hints we may have
	$hint = "";
	$q = "%" . $q . "%";	// so it works as a wildcard in the DB

	if ($stmt->prepare("SELECT FirstName, LastName FROM jr_quahog WHERE LastName LIKE ?")) {

		/* bind params */
		$stmt->bind_param("s",$q);

		/* execute query */
		$stmt->execute();
	
		/* bind your result columns to variables */
		$stmt->bind_result($FirstName, $LastName);
	
		/* store result */
		$stmt->store_result();	
	
		while($stmt->fetch()) {
			// for the first result, we simply add the result
			if ($hint=="") $hint = $FirstName." ".$LastName;
			// for subsequent results we add in a comma
			else $hint = $hint." , ".$FirstName." ".$LastName;
		}
		
		// Set output to "no suggestion" if no hint were found
		// or to the correct values
		if ($hint == "") $response="no suggestion";
		else $response=$hint; 
		
		//output the response
		echo $response;
	}
}


function getUser($q, $stmt) {
	if ($stmt->prepare("SELECT * FROM jr_quahog WHERE id= ?")) {

		/* bind params */
		$stmt->bind_param("i",$q);

		/* execute query */
		$stmt->execute();
	
		/* bind your result columns to variables */
		$stmt->bind_result($id, $FirstName, $LastName, $Age, $Hometown, $Job);
	
		/* store result */
		$stmt->store_result();
	
		if($stmt->num_rows){    // are there any results?
	
			echo "<table border='1'>
					<tr>
					<th>Firstname</th>
					<th>Lastname</th>
					<th>Age</th>
					<th>Hometown</th>
					<th>Job</th>
					</tr>";
	
			while($stmt->fetch()) {
				  echo "<tr>";
				  echo "<td>" . $FirstName. "</td>";
				  echo "<td>" . $LastName . "</td>";
				  echo "<td>" . $Age . "</td>";
				  echo "<td>" . $Hometown . "</td>";
				  echo "<td>" . $Job . "</td>";
				  echo "</tr>";
			}	
			echo "</table>";	
		}
	}
}


function liveSearch($q, $stmt) {
	// here we set the initial value of any hints we may have
	$hint = "";
	$q = "%" . $q . "%";	// so it works as a wildcard in the DB

	if ($stmt->prepare("SELECT id, FirstName, LastName FROM jr_quahog WHERE LastName LIKE ?")) {

		/* bind params */
		$stmt->bind_param("s",$q);

		/* execute query */
		$stmt->execute();
	
		/* bind your result columns to variables */
		$stmt->bind_result($id, $FirstName, $LastName);
	
		/* store result */
		$stmt->store_result();	
	
		while($stmt->fetch()) {
			// for the first result, we simply add the result
			if ($hint=="") $hint = "<a href='?func=getuser&q=".$id."'>".$FirstName." ".$LastName."</a>\n";
			// for subsequent results, we add in a br tag
			else $hint = $hint."<br/>\n"."<a href='?func=getuser&q=".$id."'>".$FirstName." ".$LastName."</a>\n";
		}
		
		//output the response -- here using conditional expression for conciseness
		echo ($hint == "")?"no suggestion":$hint;
	}
}


function combo($q, $stmt) {
	$q = "%" . $q . "%";	// so it works as a wildcard in the DB
	// NB: at the moment this means that if q is "", we get back everything in the DB
	// -- which may or may not be what we want ...

	if ($stmt->prepare("SELECT * FROM jr_quahog WHERE LastName LIKE ?")) {

		/* bind params */
		$stmt->bind_param("s",$q);

		/* execute query */
		$stmt->execute();
	
		/* bind your result columns to variables */
		$stmt->bind_result($id, $FirstName, $LastName, $Age, $Hometown, $Job);
	
		/* store result */
		$stmt->store_result();	
	
		if($stmt->num_rows){	// are there any results?
	
			echo "<table border='1'>
					<tr>
					<th>Firstname</th>
					<th>Lastname</th>
					<th>Age</th>
					<th>Hometown</th>
					<th>Job</th>
					</tr>";
	
			while($stmt->fetch()) {
				  echo "<tr>";
				  echo "<td>" . $FirstName. "</td>";
				  echo "<td>" . $LastName . "</td>";
				  echo "<td>" . $Age . "</td>";
				  echo "<td>" . $Hometown . "</td>";
				  echo "<td>" . $Job . "</td>";
				  echo "</tr>";
			}
		
			echo "</table>";
		}
	}
}

?> 
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>AJAX 1</title>
</head>

<body>
<html>
<head>
<script src="js/jquery.min.js"></script>
<!-- 
	using a local copy of jQuery ~~ could also use an online one
 -->
<script type="text/javascript">	

/*
This code adapted from Jules' xmlhttp code

Explanation: When the query is sent from the JavaScript to the PHP file, the following happens:

    PHP opens a connection to a MySQL server
    The correct person is found
    An HTML table is created, filled with data, and sent back to the "txtHint" placeholder

*/

// These javascript functions are called in response to user actions, set as handlers on
// the HTML elements they relate to.  In jQuery it would me more natural to set the handlers
// in a function that runs when the page loads.

// the function is called when the user changes the value of the form select below
function showUser(str)
{
// if the string == empty then the first option was selected
// so we set the HTML inside our Div to be empty, then quit the script
if (str=="")
  {
  $("#responseTable").html("");
  return;
  }
  	// create jQuery AJAX call -- can always use the same pattern as here
	var request = $.ajax({
		type: 'GET',	// needs to be the http method that the PHP code is expecting
		url: "",		// empty URL implies use the URL of the current file
		success: function(response) {	// anonymous function to call if AJAX request successful
			$("#responseTable").html(response);		
		},
		failure: function() {	// anonymous function to call if AJAX request unsuccessful
			console.log("ajax failure!");
		},
		data: "func=getuser&q=" + str,		// The query string for the request
	});
}


/*
Explanation: If there is any text sent from the JavaScript the following happens:

    Find a name matching the characters sent from the JavaScript
    If no match were found, set the response string to "no suggestion"
    If one or more matching names were found, set the response string to all these names
    The response is sent to the "txtHint" placeholder

*/

// see the annotations above for an explanation of this code, since it's mostly the same
function showHint(str)
{
if (str.length==0)
  {
  $("#txtHint").html("");;
  return;
  }
  
	var request = $.ajax({
		type: 'GET',	// needs to be the http method that the PHP code is expecting
		url: "",
		success: function(response) {
			$("#txtHint").html(response);		
		},
		failure: function() {
			console.log("ajax failure!");
		},
		data: "func=gethint&q=" + str,
	});
}


function showResult(str)
{
if (str.length==0)
  {
  $("#livesearch").html("");
  $("#livesearch").css("border", "0px");
  return;
  }
  	var request = $.ajax({
		type: 'GET',	// needs to be the http method that the PHP code is expecting
		url: "",
		success: function(response) {
			$("#livesearch").html(response);
			$("#livesearch").css("border", "1px solid #A5ACB2");
		},
		failure: function() {
			console.log("ajax failure!");
		},
		data: "func=livesearch&q=" + str,
	});
}

</script>
</head>
<body>
<h2>Example 1</h2>
<!-- lookup in db based on select > option -->
<form>
<select name="users" onchange="showUser(this.value)">
<option value="">Select a person:</option>
<option value="1">Peter Griffin</option>
<option value="2">Lois Griffin</option>
<option value="3">Glenn Quagmire</option>
<option value="4">Joseph Swanson</option>
</select>
</form>
<br />
<div id="responseTable">Person info will be listed here.</div>

<h2>Example 2</h2>
<!-- lookup in db based on input -->
<p>Start typing a name in the input field below:</p>
<!-- empty action URL implies use the URL of the current file -->
<form action="" method="post">
Last name: <input type="text" name="LastName" onkeyup="showHint(this.value)" size="20" />
<input type="submit" name="submit" value="submit"/>
</form>
<p>Suggestions: <span id="txtHint"></span></p>


<h2>Example 3</h2>
<form>
<input type="text" size="30" onkeyup="showResult(this.value)" />
<div id="livesearch"></div>
</form>
 
</body>
</html>
