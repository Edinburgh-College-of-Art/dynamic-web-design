<?php
include("../../../php_functions/functions.php");

// this code adapted from http://www.w3schools.com/php/php_ajax_database.asp

// here we retrieve the value passed into the url
$q = "";
if(isset($_GET["q"])) $q = "%" . $_GET["q"] . "%"; // NB the percent symbols are used to add 'wildcards'

// here we set the initial value of any hints we may have
$hint = "";

// get a DB connection
$mysqli = getConnection();

/* create a prepared statement */
$stmt =  $mysqli->stmt_init();

if ($stmt->prepare("SELECT FirstName, LastName FROM jr_quahog WHERE LastName LIKE ?")) {

	/* bind params */
    $stmt->bind_param("s",$q);

    /* execute query */
    $stmt->execute();
	
	/* bind your result columns to variables */
    $stmt->bind_result($FirstName, $LastName);
	
	/* store result */
    $stmt->store_result();	
	
    while($stmt->fetch()) {
		// for the first result, we simply add the result
		if ($hint=="") $hint = $FirstName." ".$LastName;
		// for subsequent results we add in a comma
      	else $hint = $hint." , ".$FirstName." ".$LastName;
    	}
	
	
    /* close statement */
    $stmt->close();
}

/* close connection */
$mysqli->close();

// Set output to "no suggestion" if no hint were found
// or to the correct values
if ($hint == "")
  {
  $response="no suggestion";
  }
else
  {
  $response=$hint;
  }

//output the response
echo $response;
?>
