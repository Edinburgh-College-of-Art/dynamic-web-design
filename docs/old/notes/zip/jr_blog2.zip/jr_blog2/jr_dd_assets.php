<?php include '../../functions.php'; ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<!-- this tells the browser to declare its width -->
<meta name="viewport" content="width=device-width;" />
<title>DD Assets</title>
<!-- this is the link to our basic stylesheet -->
<link href="css/jr_dd_basic.css" rel="stylesheet" type="text/css" />
<!-- this is the link to the google font -->
<!-- read more at http://www.google.com/webfonts -->
<link href='http://fonts.googleapis.com/css?family=Anaheim' rel='stylesheet' type='text/css'>
<!-- this is where we import the styles for a 'screen' -->
<style type="text/css" media="screen">
@import url("css/jr_dd_screen.css");
</style>
<!-- this is where we link to the mediaqueries css to serve styles for different platforms -->
<!-- Phone Portrait -->
<link href="css/jr_dd_mobile_320.css" rel="stylesheet" type="text/css" media="only screen and (max-width:320px)" />
<!-- this is where we add the styles for the lightbox -->
<!-- read more at http://lokeshdhakar.com/projects/lightbox2/ -->
<link href="css/lightbox.css" rel="stylesheet" type="text/css" />
</head>

<body id="b_assets">
<!-- by giving the body tag an id we can target other elements in the document to modify page specific css  e.g. a particular banner or background image -->

<!-- this div keeps the content centered and fixes the width -->
<!-- sometimes this div will have an id of 'wrapper' or 'container' -->
<div id="page">

<!-- banner -->
<div id="banner">
<h1>Readymade</h1>
</div>

<!-- start navbar -->
<div id="navbar">
	<?php include 'jr_dd_inc_nav.php'; ?>
  	<br class="clearBoth"/>
 	<!-- clears the float of the nav -->
</div>
<!-- close navbar -->

<!-- start left -->
<div id="left">
<!-- add padding - this keeps the content from aligning hard against the side of the div -->
<div class="addPadding">
<h2>Some kind of secondary nav H2</h2>
<ul id="leftnav">
  <li> quia voluptas sit </li>
  <li>aspernatur aut </li>
  <li>odit aut </li>
  <li>fugit sed quia</li>
</ul>
<h2>Left Header H2</h2>
<p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. </p>
<p>Nemo enim <a href="http://www.lipsum.com">ipsam voluptatem</a></p>
</div>
<!-- close padding -->
</div>
<!-- close left -->

<div id="main">
<!-- start main -->

<!-- images go here - i don't want padding! -->
<!-- thumbs -->
<a href="images/rm_pic_barrels.jpg" rel="lightbox[one]" title="Beer Barrels, Traquair Brewery, Peebles"><img src="images/rm_thm_barrels.jpg" width="166" height="166" alt="Beer Barrels"  class="floatImage"/></a>
<a href="images/rm_pic_icecream.jpg" rel="lightbox[one]" title="Dropped ice-cream, Waverley Bridge, Edinburgh"><img src="images/rm_thm_icecream.jpg" width="166" height="166" alt="Ice Cream"  class="floatImage"/></a>
<a href="images/rm_pic_markings.jpg" rel="lightbox[one]" title="Road Markings Test, Granville Bridge, Vancouver"><img src="images/rm_thm_markings.jpg" width="166" height="166" alt="Markings"  class="floatImage"/></a>
<a href="images/rm_pic_toilets.jpg" rel="lightbox[one]" title="Toilets, Sam Burns' Yard, Preston Pans"><img src="images/rm_thm_toilets.jpg" width="166" height="166" alt="Toilets"  class="floatImage"/></a>
<a href="images/rm_pic_type.jpg" rel="lightbox[one]" title="Type Blocks, Kreuzberg Market, Berlin"><img src="images/rm_thm_type.jpg" width="166" height="166" alt="Type"  class="floatImage"/>
<a href="images/rm_pic_villa.jpg" rel="lightbox[one]" title="Villa Ricca, Patti, Sicily"><img src="images/rm_thm_villa.jpg" width="166" height="166" alt="Villa"  class="floatImage"/></a>

<br class="clearBoth"/>
<!-- clears the float of the images -->

<div class="addPadding">
  <!-- add padding -->
<h2>Right Header H2</h2>
<p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. </p>
<p>Nemo enim <a href="http://www.lipsum.com">ipsam voluptatem</a></p>
<!-- close padding -->
</div>
<!-- close main -->
</div>

<br class="clearBoth"/>
<!-- clears the float of the left and main divs -->

<!-- start footer -->
<div id="footer">
<!-- add padding -->
<div class="addPadding">
<p>Footer</p>
</div>
<!-- close padding -->
</div>
<!-- close footer -->

</div>
<!-- close page -->

</body>
<!-- this is where we add the links to the js for the lightbox, by putting it at the bottom we ensure that the scripts can't be used before the page has fully loaded -->
<script src="js/jquery-1.7.2.min.js"></script>
<script src="js/lightbox.js"></script>
<script type="text/javascript" language="javascript">
function showSubNav(subNavToShow){
	if(document.getElementById(subNavToShow).className == "subNavOpen")
		document.getElementById(subNavToShow).className = "subNavClosed";
	else document.getElementById(subNavToShow).className = "subNavOpen"
}
</script>
</html>
