<?php include '../../functions.php'; ?>
<!-- the bit above grabs code from the page it includes -->
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>JR - PHP - INDEX</title>
</head>

<body>
<!-- do the deletion before you try to get new content -->
<?php
$cb = 0;

if(isset($_POST["delete_submit_check"])){
echo "<p>Delete was clicked</p>";
// count the number of selected objects
$cb = count($_POST['checkboxes']);// same as myArray.length()
// loop around the array to get back the id's 
for($i = 0; $i < $cb; $i++){
 echo "You want to delete id: ".$_POST['checkboxes'][$i];
	}
}

// db stuff starts here
// get connection
$mysqli = getConnection();

/* create a prepared statement */
$stmt =  $mysqli->stmt_init();



if ($stmt->prepare("DELETE FROM jr_blogpost WHERE id = ?")) {
	
	// we loop around our array of id's to populate the ?
	for($i = 0; $i < $cb; $i++){
	
	/* bind parameters for ? markers, in this integer id */
    $stmt->bind_param("i", $_POST['checkboxes'][$i]);

    /* execute query */
    $stmt->execute();
	
	}
	
    /* close statement */
    $stmt->close();
}

/* close connection */
$mysqli->close();
	
	

?>

<form action="delete.php" method="post">
<p>Select some blog posts to delete</p>

<?php

/* getConnection() function is in the functions.php that is 'included' at the top */
$mysqli = getConnection();


/* create a prepared statement */
$stmt =  $mysqli->stmt_init();

if ($stmt->prepare("SELECT id, post_title FROM jr_blogpost ORDER BY post_date DESC")) {

    /* execute query */
    $stmt->execute();
	
	/* bind your result columns to variables, e.g. id column = $post_id */
    $stmt->bind_result($post_id, $post_title);
	
	/* store result */
    $stmt->store_result();
	
	if($stmt->num_rows){// are there any results?
	
	/* show the number of results */
	//echo "<p>There are ".$stmt->num_rows." posts<p>";
	
	echo "<ul>\n";// open a list, \n = new line
	
	
	/* fetch the result of the query & loop round the results */
    while($stmt->fetch()) {
		// for each row in the resultset print out a link in a list item
		// NB the link includes a url parameter (p_id here, but whatever you want)
		// that is passed to the detail page, and picked up via $_GET
        echo "<li><input type='checkbox' name='checkboxes[]' value='".$post_id."'/> ".$post_title."</li>\n";
		// dot delimited query values \" escaped character
    	}
		
		
	echo "</ul>\n"; // close the list,  \n = new line
	}
	
	
	else {// there aren't any results
		echo "<p>There isn't any content to delete</p>";
	}

	
    /* close statement */
    $stmt->close();
}

/* close connection */
$mysqli->close();

?>

<!-- the hidden field is used to check that the form was submitted, and also which form -->
<input type="hidden" name="delete_submit_check" value="1"/>
<input type="submit" name="submit" value="submit"/>
</form>

</body>
</html>