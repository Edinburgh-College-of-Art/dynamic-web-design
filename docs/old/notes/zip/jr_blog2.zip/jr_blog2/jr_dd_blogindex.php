<?php include '../../functions.php'; ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<!-- this tells the browser to declare its width -->
<meta name="viewport" content="width=device-width;" />
<title>DD Homepage</title>
<!-- this is the link to our basic stylesheet -->
<link href="css/jr_dd_basic.css" rel="stylesheet" type="text/css" />
<!-- this is the link to the google font -->
<!-- read more at http://www.google.com/webfonts -->
<link href='http://fonts.googleapis.com/css?family=Anaheim' rel='stylesheet' type='text/css' />
<!-- this is where we import the styles for a 'screen' -->
<style type="text/css" media="screen">
@import url("css/jr_dd_screen.css");
</style>
<!-- this is where we link to the mediaqueries css to serve styles for different platforms -->
<!-- Phone Portrait -->
<link href="css/jr_dd_mobile_320.css" rel="stylesheet" type="text/css" media="only screen and (max-width:320px)" />
</head>

<body id="b_blog">
<!-- by giving the body tag an id we can target other elements in the document to modify page specific css  e.g. a particular banner or background image -->

<!-- this div keeps the content centered and fixes the width -->
<!-- sometimes this div will have an id of 'wrapper' or 'container' -->
<div id="page">

<!-- banner -->
<div id="banner">
<h1>Readymade</h1>
</div>

<!-- start navbar -->
<div id="navbar">
	<?php include 'jr_dd_inc_nav.php'; ?>
  	<br class="clearBoth"/>
 	<!-- clears the float of the nav -->
</div>
<!-- close navbar -->

<!-- start left -->
<div id="left">
<!-- add padding - this keeps the content from aligning hard against the side of the div -->
<div class="addPadding">
<h2>Left Header H2</h2>
<p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. </p>
<p>Nemo enim <a href="http://www.lipsum.com">ipsam voluptatem</a></p>
</div>
<!-- close padding -->
</div>
<!-- close left -->

<!-- start main -->
<div id="main">
<!-- images go here - i don't want padding! -->
<!-- main image -->
<img src="images/rm_pic_icecream.jpg" width="498" height="334" alt="dropped icecream" class="bigImg"/>

<!-- add padding -->
<div class="addPadding"> 
<h2>Right Header H2</h2>
<?php getBlogIndexBasic(); ?>
</div>
<!-- close padding -->
</div>
<!-- close main -->

<br class="clearBoth"/>
<!-- clears the float of the left and main divs -->

<!-- start footer -->
<div id="footer">
<!-- add padding -->
<div class="addPadding">
<p>Footer</p>
</div>
<!-- close padding -->
</div>
<!-- close footer -->

</div>
<!-- close page -->

</body>
</html>
