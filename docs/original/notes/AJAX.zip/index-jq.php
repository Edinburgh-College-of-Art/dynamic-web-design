<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>AJAX 1</title>

<script src="js/jquery.min.js"></script>
<!-- 
	using a local copy of jQuery ~~ could alternatively use an online one
 -->
<script type="text/javascript">	

/*
This code adapted from Jules' xmlhttp code

Explanation: When the query is sent from the JavaScript to the PHP file, the following happens:

    PHP opens a connection to a MySQL server
    The correct person is found
    An HTML table is created, filled with data, and sent back to the "txtHint" placeholder

*/


// the function is called when the user changes the value of the form select below
function showUser(str)
{
// if the string == empty then the first option was selected
// so we set the HTML inside our Div to be empty, then quit the script
if (str=="")
  {
  $("#responseTable").html("");
  return;
  }
 
   	// create jQuery AJAX call -- can always use the same pattern as here
	var request = $.ajax({		// In this case the variable "request" is not used anywhere
		type: 'GET',	// needs to be the http method that the PHP code is expecting
		url: "jr_getuser.php",
		success: function(response) {	// anonymous function to call if AJAX request successful
			$("#responseTable").html(response);		
		},
		failure: function() {	// anonymous function to call if AJAX request unsuccessful
			console.log("ajax failure!");
		},
		data: "q=" + str,		// The query string for the request
	});
}


/*
This code adapted from http://www.w3schools.com/php/php_ajax_php.asp

Explanation: If there is any text sent from the JavaScript the following happens:

    Find a name matching the characters sent from the JavaScript
    If no match were found, set the response string to "no suggestion"
    If one or more matching names were found, set the response string to all these names
    The response is sent to the "txtHint" placeholder

*/

// see the annotations above for an explanation of this code, since it's mostly the same
function showHint(str)
{
if (str.length==0)
  {
  $("#txtHint").html("");;
  return;
  }
  
	var request = $.ajax({
		type: 'GET',	// needs to be the http method that the PHP code is expecting
		url: "jr_gethint.php",
		success: function(response) {
			$("#txtHint").html(response);		
		},
		failure: function() {
			console.log("ajax failure!");
		},
		data: "q=" + str,
	});
}


function showResult(str)
{
if (str.length==0)
  {
  $("#livesearch").html("");
  $("#livesearch").style.border="0px";
  return;
  }
  	var request = $.ajax({
		type: 'GET',	// needs to be the http method that the PHP code is expecting
//		url: "http://playground.eca.ed.ac.uk/~jrawlins/ajax/jr_livesearch.php",	// would normally be a relative URL
		url: "jr_livesearch.php",
		success: function(response) {
			$("#livesearch").html(response);
			$("#livesearch").css("border","1px solid #A5ACB2");
		},
		failure: function() {
			console.log("ajax failure!");
		},
		data: "q=" + str,
	});
}

</script>
</head>
<body>
<h2>Example 1</h2>
<!-- lookup in db based on select > option -->
<form>
<select name="users" onchange="showUser(this.value)">
<option value="">Select a person:</option>
<option value="1">Peter Griffin</option>
<option value="2">Lois Griffin</option>
<option value="3">Glenn Quagmire</option>
<option value="4">Joseph Swanson</option>
</select>
</form>
<br />
<div id="responseTable">Person info will be listed here.</div>

<h2>Example 2</h2>
<!-- lookup in db based on input -->
<p>Start typing a name in the input field below:</p>
<form action="jr_combo.php" method="post">
Last name: <input type="text" name="LastName" onkeyup="showHint(this.value)" size="20" />
<input type="submit" name="submit" value="submit"/>
</form>
<p>Suggestions: <span id="txtHint"></span></p>


<h2>Example 3</h2>
<form>
<input type="text" size="30" onkeyup="showResult(this.value)" />
<div id="livesearch"></div>
</form>
 
</body>
</html>
