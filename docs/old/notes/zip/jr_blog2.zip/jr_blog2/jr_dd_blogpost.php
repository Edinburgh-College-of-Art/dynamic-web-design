<?php include '../../functions.php'; ?>
<?php include 'jr_fn_blogpost.php'; ?>
<?php include 'jr_dd_inc_header.php'; ?>

<body id="b_blog">
<!-- by giving the body tag an id we can target other elements in the document to modify page specific css  e.g. a particular banner or background image -->

<!-- this div keeps the content centered and fixes the width -->
<!-- sometimes this div will have an id of 'wrapper' or 'container' -->
<div id="page">

<!-- banner -->
<div id="banner">
<h1>Readymade</h1>
</div>

<!-- start navbar -->
<div id="navbar">
	<?php include 'jr_dd_inc_nav.php'; ?>
  	<br class="clearBoth"/>
 	<!-- clears the float of the nav -->
</div>
<!-- close navbar -->

<!-- start left -->
<div id="left">
<!-- add padding - this keeps the content from aligning hard against the side of the div -->
<div class="addPadding">
<h2>Left Header H2</h2>
<p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. </p>
<p>Nemo enim <a href="http://www.lipsum.com">ipsam voluptatem</a></p>
</div>
<!-- close padding -->
</div>
<!-- close left -->

<div id="main">
<!-- start main -->
<div class="addPadding">
<!-- add padding -->
<h2 id="bp_title"><?php echo $bp_title ?></h2>
<!-- tag below demonstrates default date function -->
<p>Unformatted datetime: <?php getBpDate(""); ?></p>
<!-- tag below demonstrates passing date format into function -->
<p>Formatted datetime: <?php getBpDate("d M y"); ?></p>
<div id="bp_text"><?php getBpText(); ?></div>
<!-- tag below demonstrates passing tags into a function -->
<p>By: <?php getBpAuthor("<strong>","</strong>"); ?><p>

<!-- show comments -->
<?php showComments(); ?>
<!-- comments form -->
<?php showCommentsForm(); ?>
<!-- close padding -->
</div>
<!-- close main -->
</div>

<br class="clearBoth"/>
<!-- clears the float of the left and main divs -->

<!-- start footer -->
<div id="footer">
<!-- add padding -->
<div class="addPadding">
<p>Footer</p>
</div>
<!-- close padding -->
</div>
<!-- close footer -->

</div>
<!-- close page -->

</body>
<?php include 'jr_dd_inc_footer.php'; ?>