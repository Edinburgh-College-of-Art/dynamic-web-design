<?php
// SET/GET A PAGE ID

$post_id_url = (isset($_GET['p_id'])?$_GET['p_id']:0);

// IS THIS AN INSERT OF A COMMENT? check to see if form was submitted via a hidden field
// NB you MUST insert the comment before you try to retrieve it

if(isset($_POST['comment_submit_check'])) insertComment($post_id_url);

// GETTING THE PAGE CONTENT - similar to a 'page' entity

$bp_id;
$bp_title;
$bp_text;
$bp_author;
$bp_date;

/* getConnection() function is in the functions.php that is 'included' at the top */
$mysqli = getConnection();

/* create a prepared statement */
$stmt =  $mysqli->stmt_init();

if ($stmt->prepare("SELECT id, post_title, post_text, post_author, post_date FROM jr_blogpost WHERE id = ?")) {
	
	/* bind parameters for markers */
    $stmt->bind_param("i", $post_id_url);

    /* execute query */
    $stmt->execute();
	
	/* bind your result columns to variables */
    $stmt->bind_result($id, $post_title, $post_text, $post_author, $post_date);
	
	/* store result */
    $stmt->store_result();
	
	if($stmt->num_rows){// are there any results?
	
	/* show the number of results */
	//echo "<p>".$stmt->num_rows."<p>";
	
	/* fetch the result of the query */
    while($stmt->fetch()) {
		// global $bp_id, $bp_title, $bp_text, $bp_author;
		$bp_id = $id;
        $bp_title = $post_title;
		$bp_text = $post_text;
		$bp_author = $post_author;
		$bp_date = $post_date;
    	}
	
	}
	
	else {// there aren't any results
		//
	}

	
    /* close statement */
    $stmt->close();
}

/* close connection */
$mysqli->close();

// SIMPLE FUNCTIONS - BUT MAKE CODE EASIER TO READ AND DEPLOY

function getBpID(){
	global $bp_id;
	echo $bp_id;
}

function getBpTitle(){
	global $bp_title;
	echo $bp_title;
}

function getBpText(){
	global $bp_text;
	echo $bp_text;
}

// in this example we can use startTag & endTag to wrap
// HTML tags around an entity
function getBpAuthor($startTag,$endTag){
	global $bp_author;
	echo $startTag.$bp_author.$endTag;
}

function getBpDate($format){
	global $bp_date;
	// echo $bp_date;
	if($format == "") $format = "d-m-Y H:i:s";
	// for more on formats see http://php.net/manual/en/function.date.php
	$bp_date = strtotime($bp_date); // converting to php timestamp
	$bp_date = date($format, $bp_date ); // using timestamp to format
	echo $bp_date;
}

function insertComment($pid){

/* getConnection() function is in the functions.php that is 'included' at the top */
$mysqli = getConnection();

/* assign parameter values */
$post_text = $_POST['post_text'];
$post_author = $_POST['post_author'];

/* create a prepared statement */
$stmt =  $mysqli->stmt_init();

if ($stmt->prepare("INSERT INTO jr_blogcomment (post_id, comment_text, comment_author, comment_date)
	VALUES (?,?,?,NOW())")) {

    /* bind parameters for ? markers, NB $post_id_url comes from our url parameter */
    $stmt->bind_param("iss", $pid, $post_text, $post_author);

    /* execute query */
    $stmt->execute();
	
    /* close statement */
    $stmt->close();
}

/* close connection */
$mysqli->close();

}

function showComments(){
	global $post_id_url;

	$mysqli = getConnection();


	/* create a prepared statement */
	$stmt =  $mysqli->stmt_init();

	if ($stmt->prepare("SELECT comment_text, comment_author FROM jr_blogcomment WHERE post_id = ? 	 ORDER BY comment_date DESC")) {
	
		/* bind parameters for markers */
    	$stmt->bind_param("i", $post_id_url);

    	/* execute query */
    	$stmt->execute();
	
		/* bind your result columns to variables */
    	$stmt->bind_result($comment_text, $comment_author);
	
		/* store result */
    	$stmt->store_result();
	
		if($stmt->num_rows){// are there any results?
	
		/* show the number of results */
		//echo "<p>".$stmt->num_rows."<p>";
		echo "<h3>Comments</h3>";
	
		/* fetch the result of the query & loop round the results */
    	while($stmt->fetch()) {
			echo "<div>".$comment_text."</div>";
			echo "<div>Author: ".$comment_author."</div>";
    		}
	
		}
	
		else {// there aren't any results
			echo "<p>There aren't any comments</p>";
		}

	
    	/* close statement */
    	$stmt->close();
}

/* close connection */
$mysqli->close();

}

function showCommentsForm(){
global $post_id_url;
// jump out of PHP
?>
<form action="?p_id=<?php echo $post_id_url; ?>" method="post">
<div>
<h3>Add your comment:</h3>
<p>Comment</p>
<textarea name="post_text"></textarea>
</div>
<div>
<p>Author</p>
<input type="text" name="post_author"/>
</div>
<div>
<p>&nbsp;</p>
<input type="hidden" name="comment_submit_check" value="1"/> 
<input type="submit" name="submit"/>
</div>
</form>	

<?php
// jump back into PHP

}
?>